package net.mcreator.futuristiccars.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.client.Minecraft;

import net.mcreator.futuristiccars.network.FuturisticcarsModVariables;
import net.mcreator.futuristiccars.entity.FlyingCarEntity;

import com.mojang.blaze3d.platform.InputConstants;

public class CarsTickProceduresProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.isVehicle()) {
			if (InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), InputConstants.KEY_Z)) {
				if (entity.isVehicle()) {
					FuturisticcarsModVariables.moveup = 1;
				}
			} else {
				FuturisticcarsModVariables.moveup = 0;
			}
			if (InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), InputConstants.KEY_X)) {
				if (entity.isVehicle()) {
					FuturisticcarsModVariables.movedown = 1;
				}
			} else {
				FuturisticcarsModVariables.movedown = 0;
			}
			if (entity.isVehicle()) {
				if (FuturisticcarsModVariables.moveup == 1) {
					FuturisticcarsModVariables.Y = FuturisticcarsModVariables.Y + 0.09;
					entity.setDeltaMovement(new Vec3(0, 0.09, 0));
				}
			}
			if (entity.isVehicle()) {
				if (FuturisticcarsModVariables.moveup == 0) {
					FuturisticcarsModVariables.Y = 0;
				}
			}
			if (entity.isVehicle()) {
				if (FuturisticcarsModVariables.movedown == 1) {
					FuturisticcarsModVariables.Y = FuturisticcarsModVariables.Y - 0.09;
					entity.setDeltaMovement(new Vec3(0, (-0.09), 0));
				}
			}
			if (entity.isVehicle()) {
				if (FuturisticcarsModVariables.movedown == 0) {
					FuturisticcarsModVariables.Y = 0;
				}
			}
			if (entity.isVehicle()) {
				if (Minecraft.getInstance().options.keyLeft.isDown()) {
					if (entity instanceof FlyingCarEntity) {
						((FlyingCarEntity) entity).setAnimation("moveleft");
					}
					{
						Entity _ent = entity;
						_ent.setYRot((float) (entity.getYRot() - 3));
						_ent.setXRot(entity.getXRot());
						_ent.setYBodyRot(_ent.getYRot());
						_ent.setYHeadRot(_ent.getYRot());
						_ent.yRotO = _ent.getYRot();
						_ent.xRotO = _ent.getXRot();
						if (_ent instanceof LivingEntity _entity) {
							_entity.yBodyRotO = _entity.getYRot();
							_entity.yHeadRotO = _entity.getYRot();
						}
					}
				} else {
					if (Minecraft.getInstance().options.keyRight.isDown()) {
						if (entity instanceof FlyingCarEntity) {
							((FlyingCarEntity) entity).setAnimation("mover");
						}
						{
							Entity _ent = entity;
							_ent.setYRot((float) (entity.getYRot() + 3));
							_ent.setXRot(entity.getXRot());
							_ent.setYBodyRot(_ent.getYRot());
							_ent.setYHeadRot(_ent.getYRot());
							_ent.yRotO = _ent.getYRot();
							_ent.xRotO = _ent.getXRot();
							if (_ent instanceof LivingEntity _entity) {
								_entity.yBodyRotO = _entity.getYRot();
								_entity.yHeadRotO = _entity.getYRot();
							}
						}
					} else {
						if (entity instanceof FlyingCarEntity) {
							((FlyingCarEntity) entity).setAnimation("empty");
						}
					}
				}
			}
		} else {
			if (!entity.onGround()) {
				entity.setOnGround(true);
			}
		}
	}
}
