
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.futuristiccars.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.futuristiccars.world.inventory.INVMenu;
import net.mcreator.futuristiccars.FuturisticcarsMod;

public class FuturisticcarsModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, FuturisticcarsMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<INVMenu>> INV = REGISTRY.register("inv", () -> IMenuTypeExtension.create(INVMenu::new));
}
