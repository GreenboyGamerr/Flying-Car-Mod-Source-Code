
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.futuristiccars.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.futuristiccars.entity.FlyingCarEntity;
import net.mcreator.futuristiccars.entity.FastestFlyingCarEntity;
import net.mcreator.futuristiccars.entity.AdvancedFlyingCarEntity;
import net.mcreator.futuristiccars.FuturisticcarsMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class FuturisticcarsModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, FuturisticcarsMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<FlyingCarEntity>> FLYING_CAR = register("flying_car",
			EntityType.Builder.<FlyingCarEntity>of(FlyingCarEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<AdvancedFlyingCarEntity>> ADVANCED_FLYING_CAR = register("advanced_flying_car",
			EntityType.Builder.<AdvancedFlyingCarEntity>of(AdvancedFlyingCarEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<FastestFlyingCarEntity>> FASTEST_FLYING_CAR = register("fastest_flying_car",
			EntityType.Builder.<FastestFlyingCarEntity>of(FastestFlyingCarEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerEntity(Capabilities.ItemHandler.ENTITY, FLYING_CAR.get(), (living, context) -> living.getInventory());
		event.registerEntity(Capabilities.ItemHandler.ENTITY, ADVANCED_FLYING_CAR.get(), (living, context) -> living.getInventory());
		event.registerEntity(Capabilities.ItemHandler.ENTITY, FASTEST_FLYING_CAR.get(), (living, context) -> living.getInventory());
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		FlyingCarEntity.init(event);
		AdvancedFlyingCarEntity.init(event);
		FastestFlyingCarEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FLYING_CAR.get(), FlyingCarEntity.createAttributes().build());
		event.put(ADVANCED_FLYING_CAR.get(), AdvancedFlyingCarEntity.createAttributes().build());
		event.put(FASTEST_FLYING_CAR.get(), FastestFlyingCarEntity.createAttributes().build());
	}
}
