
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.futuristiccars.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.futuristiccars.client.renderer.FlyingCarRenderer;
import net.mcreator.futuristiccars.client.renderer.FastestFlyingCarRenderer;
import net.mcreator.futuristiccars.client.renderer.AdvancedFlyingCarRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class FuturisticcarsModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(FuturisticcarsModEntities.FLYING_CAR.get(), FlyingCarRenderer::new);
		event.registerEntityRenderer(FuturisticcarsModEntities.ADVANCED_FLYING_CAR.get(), AdvancedFlyingCarRenderer::new);
		event.registerEntityRenderer(FuturisticcarsModEntities.FASTEST_FLYING_CAR.get(), FastestFlyingCarRenderer::new);
	}
}
