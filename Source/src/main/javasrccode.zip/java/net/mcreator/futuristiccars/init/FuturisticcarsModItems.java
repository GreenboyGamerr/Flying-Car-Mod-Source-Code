
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.futuristiccars.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.futuristiccars.item.NormalFlyingCarItem;
import net.mcreator.futuristiccars.item.FutflyingCarItem;
import net.mcreator.futuristiccars.item.ADVFlyingCarItem;
import net.mcreator.futuristiccars.FuturisticcarsMod;

public class FuturisticcarsModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FuturisticcarsMod.MODID);
	public static final DeferredItem<Item> FLYING_CAR_SPAWN_EGG = REGISTRY.register("flying_car_spawn_egg", () -> new DeferredSpawnEggItem(FuturisticcarsModEntities.FLYING_CAR, -6710887, -1, new Item.Properties()));
	public static final DeferredItem<Item> NORMAL_FLYING_CAR = REGISTRY.register("normal_flying_car", NormalFlyingCarItem::new);
	public static final DeferredItem<Item> ADVANCED_FLYING_CAR_SPAWN_EGG = REGISTRY.register("advanced_flying_car_spawn_egg", () -> new DeferredSpawnEggItem(FuturisticcarsModEntities.ADVANCED_FLYING_CAR, -10092544, -1, new Item.Properties()));
	public static final DeferredItem<Item> ADV_FLYING_CAR = REGISTRY.register("adv_flying_car", ADVFlyingCarItem::new);
	public static final DeferredItem<Item> FASTEST_FLYING_CAR_SPAWN_EGG = REGISTRY.register("fastest_flying_car_spawn_egg", () -> new DeferredSpawnEggItem(FuturisticcarsModEntities.FASTEST_FLYING_CAR, -3381760, -6724096, new Item.Properties()));
	public static final DeferredItem<Item> FUTFLYING_CAR = REGISTRY.register("futflying_car", FutflyingCarItem::new);
	// Start of user code block custom items
	// End of user code block custom items
}
